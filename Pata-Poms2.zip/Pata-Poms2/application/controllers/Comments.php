<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  Comments.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource Comments.php
 */

class Comments extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		// Menu active
		$data = array(
			"menu" => 4
		);
		// load comment managers
		$this->load->model('managers_commentaires', 'commentaires');


		// Menu active
		$data = array(
			"menu" => 4,
			"success" => false,
			"comments" => $this->commentaires->getList()
		);
		// Condition view form
		if($this->input->post('name') != null &&
			$this->input->post('email')!= null &&
			$this->input->post('message')){
			$this->commentaires->addComments(
				$this->input->post('name'),
				$this->input->post('email'),
				$this->input->post('message'));
			// Succees Vars
			$data["success"] = true;

			unset($_POST);
			// Load View
			redirect('/comments');


		}else{
			// Load View
			$this->load->view("view_comments", $data);
		}
	}
}
