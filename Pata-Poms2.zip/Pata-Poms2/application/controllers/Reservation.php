<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  Reservation.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource Reservation.php
 */

class Reservation extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{

		// Menu active
		$data = array(
			"menu" => null,
			"success" => false
		);
		// Condition view form
		if($this->input->post('date-reservation') != null &&
				$this->input->post('time-reservation')!= null &&
				$this->input->post('person-number') != null &&
				$this->input->post('order') != null &&
				$this->input->post('name') != null &&
				$this->input->post('email') != null &&
				$this->input->post('phone') != null){
			$this->load->model('managers_reservations', 'reservation');
			$this->reservation->addReservation(
				$this->input->post('date-reservation'),
				$this->input->post('time-reservation'),
				$this->input->post('person-number'),
				$this->input->post('order'),
				$this->input->post('name'),
				$this->input->post('email'),
				$this->input->post('phone')
			);
			// Succees Vars
			$data["success"] = true;

			// Load View Succees
			$this->load->view('view_reservation', $data);

			$data["success"] = false;
		}else{
			// Load View
			$this->load->view('view_reservation', $data);
		}
	}
	public function reserver(){
		echo "RESERVE";
	}
}
