<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  Info.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource Info.php
 */

class Info extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		// Menu active
		$data = array(
			"menu" => 3
		);
		// Load View
		$this->load->view("view_info", $data);
	}
}
