<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  managers_commentaires.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource managers_commentaires.php
 */

class managers_commentaires extends CI_Model
{
	protected $table = "commentaire";
	public function __construct()
	{
		parent::__construct();
	}
	public function addComments($nom, $email, $message){
		$data = array(
			'Nom' => $nom,
			'Email' => $email,
			'Message' => $message
		);
		return $this->db->insert($this->table, $data);
	}
	public function getList(){
		// SQL REQUETE
		$sql = "SELECT * FROM " . $this->table;

		// RESULTAT
		$resultat = array();


		// QUERY
		$query = $this->db->query($sql);

		$i = 0;
		// On parcourt l'ensemble des résultats
		foreach($query->result() as $comment)
		{
			$resultat[$i]['nom'] = $comment->Nom;
			$resultat[$i]['email'] = $comment->Email;
			$resultat[$i]['message'] = $comment->Message;
			$i++;
		}
		$query->free_result();
		return $resultat;
	}
}
