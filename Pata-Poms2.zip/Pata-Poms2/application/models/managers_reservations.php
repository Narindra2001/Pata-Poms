<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  managers_reservations.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource managers_reservations.php
 */

class managers_reservations extends CI_Model
{
	protected $table = "reservation";
	public function __construct()
	{
		parent::__construct();
	}
	public function addReservation($date, $heure, $nbr, $commande, $nom, $email, $phone){
		$data = array(
			'Date' => $date,
			'Heure' => $heure,
			'Nbr_Personnes' => $nbr,
			'Commande' => $commande,
			'Nom' => $nom,
			'Email' => $email,
			'Telephone' => $phone,
		);
		return $this->db->insert($this->table, $data);
	}

}
