<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  header.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource header.php
 */
;?>
<header class="top-navbar">
	<nav class="navbar navbar-expand-lg navbar-light ">
		<div class="container">
			<a class="navbar-brand" href="index.html">
				<img src="<?php echo base_url("public/assets/");?>images/PataPoms.png" alt="" width="60%" />
			</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-rs-food" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbars-rs-food">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item <?php if($menu == 1){echo "active";};?>"><a class="nav-link" href="<?php echo base_url('');?>">Accueil</a></li>
					<li class="nav-item <?php if($menu == 2){echo "active";};?>"><a class="nav-link" href="<?php echo base_url('menu');?>">ClikKaly</a></li>
					<li class="nav-item <?php if($menu == 3){echo "active";};?>"><a class="nav-link" href="<?php echo base_url('info');?>">A Propos</a></li>
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="" id="dropdown-a" data-toggle="dropdown">Pages</a>
						<div class="dropdown-menu" aria-labelledby="dropdown-a">
							<a class="dropdown-item" href="<?php echo base_url('reservation');?>">Reservation</a>
							<a class="dropdown-item" href="<?php echo base_url('stuff');?>">Coup de Coeur</a>
							<a class="dropdown-item" href="<?php echo base_url('gallery');?>">Gallery</a>
						</div>
					</li>
					<li class="nav-item <?php if($menu == 4){echo "active";};?>">
						<a class="nav-link" href="<?php echo base_url('comments');?>">Commentaires</a>
					</li>
					<li class="nav-item <?php if($menu == 5){echo "active";};?>"><a class="nav-link" href="<?php echo base_url('contacts');?>">Contact</a></li>
				</ul>
			</div>
		</div>
	</nav>
</header>


