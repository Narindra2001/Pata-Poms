<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  view_menu.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource view_menu.php
 */
;?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Site Metas -->
	<title>Pata-Poms</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="author" content="">

	<?php include("assets/stylesheets.php");?>
</head>
<style>
	.navbar{
		background: #6c757d!important;
	}
</style>
<body>
<!-- Start header -->
<?php include ('header.php');?>
<!-- End header -->

<!-- Start All Pages -->
<!-- <div class="all-page-title page-breadcrumb">
	<div class="container text-center">
		<div class="row">
			<div class="col-lg-12">
				<h1> Menus</h1>
			</div>
		</div>
	</div>
</div> -->
<!-- End All Pages -->

<!-- Start Menu -->
<div class="menu-box">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="heading-title text-center">
					<h2> Menus</h2>
					<p></p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="special-menu text-center">
					<div class="button-group filter-button-group">
						<button class="active" data-filter="*">Tout</button>
						<button data-filter=".signature">Spécialités</button>
						<button data-filter=".malagasy">Plats Malagasy</button>
						<button data-filter=".appetizer">Snacks</button>
						<button data-filter=".lunch">Plats</button>
						<button data-filter=".dinner">Pizza</button>
						<!-- <button data-filter=".dessert">Dessert</button> -->
						<button data-filter=".drinks">Boissons</button>
					</div>
				</div>
			</div>
		</div>

		<div class="row special-list">
			<div class="col-lg-4 col-md-6 special-grid appetizer">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/snacks/My salade.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Snack</h4>
						<p>My Salade Ingrédients au Choix</p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>
			</div>




			<div class="col-lg-4 col-md-6 special-grid drinks">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/mojito.png" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Special Drinks 2</h4>
						<p>Sed id magna vitae eros sagittis euismod.</p>
						<h5> 8 000 Ar</h5>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 special-grid signature">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/tarte.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Signatures</h4>
						<p>Tarte aux Pommes et au Boudin Noir </p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid signature">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/pomme.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Signatures</h4>
						<p>Galette de pomme de terre.</p>
						<h5> 15 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid signature">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/pomm1.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Signatures</h4>
						<p>Hasselback de Pommes de terre.</p>
						<h5> 15 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid signature">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/fromage.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Signatures</h4>
						<p> Muffins croustillants de pomme de terre au fromage de chèvre.</p>
						<h5> 10 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid signature">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/canard.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Signatures</h4>
						<p>Parmentier de canard aux deux pommes.</p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid signature">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/soupe.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Signatures</h4>
						<p>Soupe de pommes de terre au jambon.</p>
						<h5> 20 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid malagasy">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/amalona.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Plat Malagasy</h4>
						<p>Amalona Sauce</p>
						<h5> 30 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid malagasy">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/hen_omby_ritra.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Plat Malagasy</h4>
						<p>Hen'Omby Ritra.</p>
						<h5> 10 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid malagasy">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/crevette.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Plat Malagasy</h4>
						<p>Crevette Sauce.</p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid malagasy">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/boeuf.jpeg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Plat Malagasy</h4>
						<p>Langue de Boeuf.</p>
						<h5> 15 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid drinks">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/Jus.jpg" width="60%" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Moktails </h4>
						<p>Jus d'Orange.</p>
						<h5> 20 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid drinks">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/rhum.jpg" width="70%" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Rhum Arrangé</h4>
						<p>Consommation</p>
						<h5> 8 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid appetizer">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/snacks/assiette de sambos.jpg" width="100%" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Snack</h4>
						<p>Assiette de Sambos</p>
						<h5> 20 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid appetizer">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/snacks/Assiete de nem.jpg" width="100%" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Snack</h4>
						<p>Assiette de Nem</p>
						<h5> 20 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid appetizer">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/snacks/brochette magret de canrd.jpeg" width="100%" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Snack</h4>
						<p>Brochette Magret de Canard</p>
						<h5> 30 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid appetizer">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/snacks/panini.jpg" width="100%" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Snack</h4>
						<p>My Panini Ingrédients au Choix</p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid appetizer">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/snacks/My Hamburger.jpg" width="100%" class="img" alt="Image">
					<div class="why-text">
						<h4>Nos Snack</h4>
						<p>My Hamburger Ingrédients au Choix</p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>

			</div>
			<div class="col-lg-4 col-md-6 special-grid drinks">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/Walker.png" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Whisky</h4>
						<p>Black Label, Green Label, Red Label, JB...</p>
						<h5>En Verre : 10 000 Ar</h5>
						<h5>Bouteille 1 000 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid drinks">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/cocktail_Champagne.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Cocktails</h4>
						<p>Cocktail peche et Champagne : <br> Peches, jus de citron, Gin et Champagne</p>
						<h5> 20 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid drinks">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/cocktail_bahama_mama-1.png" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Cocktails</h4>
						<p>Bahama MAMA : <br> Rhum, noix de coco, Grenadine, Jus d'orange et jus d'ananas</p>
						<h5>15 000 Ar</h5>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 special-grid drinks">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/eau-vive-150.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Soft</h4>
						<p>Eau Vive</p>
						<h5> PM : 5 000 Ar <br>GM : 10 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid drinks">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/biere.JPG" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Soft</h4>
						<p>Bière THB</p>
						<h5>THB PM :5 000 Ar <br>THB GM : 10 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid drinks">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/Biere-pression.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Soft</h4>
						<p>Bière Pression</p>
						<h5> 5 000 Ar</h5>
					</div>
				</div>
			</div>
			<!-- <div class="col-lg-4 col-md-6 special-grid drinks">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/img-03.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Special Drinks 3</h4>
						<p>Sed id magna vitae eros sagittis euismod.</p>
						<h5> $10.79</h5>
					</div>
				</div>
			</div> -->
			<div class="col-lg-4 col-md-6 special-grid dinner">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/MyPizza.jpeg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Pizza</h4>
						<p>My Pizza: <br>Ingrédients de Votre Choix</p>
						<h5> 30 000 Ar</h5>
					</div>
				</div>
			</div>
			<!-- <div class="col-lg-4 col-md-6 special-grid dinner">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/Bambino.jpg" width="100%" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Pizza</h4>
						<p>Pizza Bambino : <br>Sauce tomates, jambon et Fromage</p>
						<h5> 27 500 Ar</h5>
					</div>
				</div>
			</div> -->




			<div class="col-lg-4 col-md-6 special-grid lunch">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/plats/blanc de poulet farcis a la mozzarella.jpg" width="90%" class="img-fluid p-0" alt="Image">
					<div class="why-text">
						<h4>Nos Plat</h4>
						<p><strong>Blancs de poulet farcis à la mozzarella :</strong> <br>Blancs de poule, farine , œufs battus, chapelur parmesan, mozzarella râpée, pulpe de tomates, gousses d'ail, branches de persil sel, poivre, flocons de piment</p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>
			</div>


			<div class="col-lg-4 col-md-6 special-grid lunch">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/plats/cake dinde et courgette.jpg" width="135%" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Plats</h4>
						<p><strong>Cake dinde et courgette :</strong> <br>Farine,Gruyère,Jambon, courgettes,Œufs,Levure,lait,huile de tournessole ,Sel,Poivre, filet de dinde.</p>
						<h5> 15 000 Ar</h5>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 special-grid lunch">
				<div class="gallery-single ">
					<img src="<?php echo base_url("public/assets/");?>images/plats/Tournedos canard.png" height="150%" class="img-100% " alt="Image">
					<div class="why-text">
						<h4>Nos Plats</h4>
						<p> <strong>Tournedos de canard et sa poêlée de légumes minute :</strong><br>tournedos de canard, pois gourmands, brocolis,tomates cerise, poivron jaune, oignon, branche de thym</p>
						<h5>28 500 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid lunch">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/plats/Osso bucco d'inde.jpg" class="img-fluid m-3" alt="Image">
					<div class="why-text">
						<h4>Nos Plats</h4>
						<p> <strong>Osso bucco dinde :</strong><br>bucco d’inde ,Céleri,Carottes, Champignons, Ail,Oignons,Feuilles de laurier, thym, concentré de tomate , Pulpe de tomates, Huile d'olive,Vin blanc,Eau,Farine,Sel,Poivre</p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid lunch">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/plats/canard confit aux pommes sautés.jpg" width="98%" class="img-fluid m-4" alt="Image">
					<div class="why-text">
						<h4>Nos Plats</h4>
						<p><strong>Canard confits aux pommes sautés :</strong><br>Cuise de canard, graisse de canard, pommes de terre, poivre</p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid lunch">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/plats/Porc caramelisé.jpg" class="img-fluid m-3" alt="Image">
					<div class="why-text">
						<h4>Nos Plats</h4>
						<p><strong>Porc caramélisé</strong><br>porc,sauce soja,quatre épices, gingembre,litre eau</p>
						<h5> 30 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid lunch">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/plats/Roti de filet de dinde.jpg" class="img-fluid " alt="Image">
					<div class="why-text">
						<h4>Nos Plats</h4>
						<p><strong>Roti dinde et pommes sautés </strong><br>Oignon jaune,Pommes de terre,Moutarde de Dijon, Poivre Acc :Pomme de terre et tomates grillés</p>
						<h5> 30 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid lunch">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/plats/Cotes de porc panées.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Plats</h4>
						<p><strong>Porc panées aux pommes sautées et salade de tomates </strong><br> côtes de porc,le jus d'un citron,oeufs , paprika doux en poudre ,chapelure</p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 special-grid lunch">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/plats/steak grilled.jpg" class="img-fluid m-3" alt="Image">
					<div class="why-text">
						<h4>Nos Plats</h4>
						<p><strong>Steak grillé de zébu grillé et salades roquettes :</strong><br>• gousse ail,huile d'olive,poivre au goût, herbes de Provence ,sel,tomates </p>
						<h5> 25 000 Ar</h5>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 special-grid dinner">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/pizza-kebab-turque.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Pizza</h4>
						<p>Pizza Kébab : Sauce tomates, Fromage, Kebab, Poivrons, Oignons<br></p>
						<h5>25 000 Ar</h5>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 special-grid dinner">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/pizza-poulet-au-curry-et-ananas.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Pizza</h4>
						<p>Pizza Hawaienne : <br>Sauce tomates, fromage, poulet au curry, annas, origan</p>
						<h5>25 000 Ar</h5>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 special-grid dinner">
				<div class="gallery-single fix">
					<img src="<?php echo base_url("public/assets/");?>images/pizzaNordique.jpg" class="img-fluid" alt="Image">
					<div class="why-text">
						<h4>Nos Pizza</h4>
						<p>Pizza La Nordique : <br> Sauce tomates,Fromages, Saumon fumé, crème ciboulette et origan</p>
						<h5> 30 000 Ar</h5>
					</div>
				</div>
			</div>

		</div>
	</div>
</div>
<!-- End Menu -->

<!-- Start QT -->
<div class="qt-box qt-background">
	<div class="container">
		<div class="row">
			<div class="col-md-8 ml-auto mr-auto text-left">
				<p class="lead ">
					" If you're not the one cooking, stay out of the way and compliment the chef. "
				</p>
				<span class="lead">Michael Strahan</span>
			</div>
		</div>
	</div>
</div>
<!-- End QT -->

<!-- Start Customer Reviews -->
<!-- <div class="customer-reviews-box">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="heading-title text-center">
					<h2>Customer Reviews</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8 mr-auto ml-auto text-center">
				<div id="reviews" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner mt-4">
						<div class="carousel-item text-center active">
							<div class="img-box p-1 border rounded-circle m-auto">
								<img class="d-block w-100 rounded-circle" src="<?php echo base_url("public/assets/");?>images/profile-1.jpg" alt="">
							</div>
							<h5 class="mt-4 mb-0"><strong class="text-warning text-uppercase">Paul Mitchel</strong></h5>
							<h6 class="text-dark m-0">Web Developer</h6>
							<p class="m-0 pt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu sem tempor, varius quam at, luctus dui. Mauris magna metus, dapibus nec turpis vel, semper malesuada ante. Idac bibendum scelerisque non non purus. Suspendisse
								varius nibh non aliquet.</p>
						</div>
						<div class="carousel-item text-center">
							<div class="img-box p-1 border rounded-circle m-auto">
								<img class="d-block w-100 rounded-circle" src="<?php echo base_url("public/assets/");?>images/profile-3.jpg" alt="">
							</div>
							<h5 class="mt-4 mb-0"><strong class="text-warning text-uppercase">Steve Fonsi</strong></h5>
							<h6 class="text-dark m-0">Web Designer</h6>
							<p class="m-0 pt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu sem tempor, varius quam at, luctus dui. Mauris magna metus, dapibus nec turpis vel, semper malesuada ante. Idac bibendum scelerisque non non purus. Suspendisse
								varius nibh non aliquet.</p>
						</div>
						<div class="carousel-item text-center">
							<div class="img-box p-1 border rounded-circle m-auto">
								<img class="d-block w-100 rounded-circle" src="<?php echo base_url("public/assets/");?>images/profile-7.jpg" alt="">
							</div>
							<h5 class="mt-4 mb-0"><strong class="text-warning text-uppercase">Daniel vebar</strong></h5>
							<h6 class="text-dark m-0">Seo Analyst</h6>
							<p class="m-0 pt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu sem tempor, varius quam at, luctus dui. Mauris magna metus, dapibus nec turpis vel, semper malesuada ante. Idac bibendum scelerisque non non purus. Suspendisse
								varius nibh non aliquet.</p>
						</div>
					</div>
					<a class="carousel-control-prev" href="#reviews" role="button" data-slide="prev">
						<i class="fa fa-angle-left" aria-hidden="true"></i>
						<span class="sr-only">Previous</span>
					</a>
					<a class="carousel-control-next" href="#reviews" role="button" data-slide="next">
						<i class="fa fa-angle-right" aria-hidden="true"></i>
						<span class="sr-only">Next</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</div> -->
<!-- End Customer Reviews -->

<!-- Start Contact info -->
<div class="contact-imfo-box">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<i class="fa fa-volume-control-phone"></i>
				<div class="overflow-hidden">
					<h4>Phone</h4>
					<p class="lead">
						+261 32 52 436 82
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<i class="fa fa-envelope"></i>
				<div class="overflow-hidden">
					<h4>E-mail</h4>
					<p class="lead">
						info@patapoms.mg
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<i class="fa fa-map-marker"></i>
				<div class="overflow-hidden">
					<h4>Localisation :</h4>
					<p class="lead">
						Cap 3000 Andraharo Antananarivo
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Contact info -->

<!-- Start Footer -->
<footer class="footer-area bg-f">
	<div class="container">
		<div class="row">

			<div class="col-lg-4 col-md-6">
				<h3><strong>Heures d'Ouverture</strong></h3>
				<p><span class="text-color"><strong>Lundi - Jeudi : </span>9h - 22h </strong>
				</p>
				<p><span class="text-color"><strong>Vendredi :</span> 9h - 23h</strong>
				</p>
				<p><span class="text-color"><strong>Samedi :</span> 16h - 22h</strong>
				</p>
				<p><span class="text-color"><strong>Dimanche :</span> Fermeture</strong>
				</p>
			</div>
			<div class="col-lg-4 col-md-6">
				<h3><strong>Contact information </strong></h3>
				<p class="lead">Rue Docteur Raseta, Cap3000 Andraharo Antananarivo</p>
				<p class="lead"><a href="#">+261 32 52 436 82</a></p>
				<p><a href="#"> info@patapoms.mg</a></p>
			</div>
			<div class="col-lg-3 col-md-6">
				<h3><strong>Réseaux Sociaux</strong></h3>
				<!-- <div class="subscribe_form">
					<form class="subscribe_form">
						<input name="EMAIL" id="subs-email" class="form_input" placeholder="Email Address..." type="email">
						<button type="submit" class="submit">DESCRIPTION</button>
						<div class="clearfix"></div>
					</form>
				</div -->
				<ul class="list-inline f-social">
					<li class="list-inline-item"><a href="https://www.facebook.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li class="list-inline-item"><a href="https://www.twitter.com"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<!-- <li class="list-inline-item"><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li> -->
					<li class="list-inline-item"><a href="https://www.instagram.com"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				</ul>
			</div>
		</div>
	</div>

	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<p class="company-name">All Rights Reserved. &copy; 2022 <a href="#">Pata-Poms Restaurant Bar Lounge</a>
						<a href="https://html.design/"></a>
					</p>
				</div>
			</div>
		</div>
	</div>

</footer>
<!-- End Footer -->

<a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

<?php include ('assets/script.php');?>
</body>

</html>
