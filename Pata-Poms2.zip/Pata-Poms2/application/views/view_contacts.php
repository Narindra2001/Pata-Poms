<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  view_contacts.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource view_contacts.php
 */;?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Site Metas -->
	<title>Pata-Poms</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="author" content="">

	<!-- Site Icons -->
	<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">

	<?php include ("assets/stylesheets.php");?>


</head>
<style>
	.navbar{
		background: #6c757d!important;
	}
</style>
<body>
<!-- Start header -->
<?php include("header.php");?>
<!-- End header -->

<!-- Start All Pages -->
<div class="all-page-title page-breadcrumb">
	<div class="container text-center">
		<div class="row">
			<div class="col-lg-12">
				<!-- <h1>Contact</h1> -->
			</div>
		</div>
	</div>
</div>
<!-- End All Pages -->

<!-- Start Contact -->
<div class="map">
	<iframe src="<?php echo base_url("public/assets/");?>https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2350.7906458562093!2d47.50926473132066!3d-18.886768219826802!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x21f080bcfef1f2ed%3A0xe41b9487415adb42!2sCAP%203000%20Andraharo!5e0!3m2!1sfr!2smg!4v1652125591489!5m2!1sfr!2smg"
			width="100%" height="650" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
<div class="contact-box">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="heading-title text-center">
					<!-- <h2>Contact</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting</p> -->
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<form id="contactForm">
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<input type="text" class="form-control" id="name" name="name" placeholder="Votre Nom" required data-error="Votre nom s'il vous plait">
								<div class="help-block with-errors"></div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<input type="email" placeholder="votre E-mail" id="email" class="form-control" name="name" required data-error="Veuillez entrer Votre e-mail">
								<div class="help-block with-errors"></div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<select class="custom-select d-block form-control" id="guest" required data-error="Veuillez sélectionné une personne">
									<option disabled selected>Personnes sélectionnées</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
								</select>
								<div class="help-block with-errors"></div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<textarea class="form-control" id="message" placeholder="Votre Message" rows="4" data-error="Write your message" required></textarea>
								<div class="help-block with-errors"></div>
							</div>
							<div class="submit-button text-center">
								<button class="btn btn-common" id="submit" type="submit">Message Envoyé</button>
								<div id="msgSubmit" class="h3 text-center hidden"></div>
								<div class="clearfix"></div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- End Contact -->

<!-- Start Contact info -->
<div class="contact-imfo-box">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<i class="fa fa-volume-control-phone"></i>
				<div class="overflow-hidden">
					<h4>Téléphonee</h4>
					<p class="lead">
						+261 32 52 436 82
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<i class="fa fa-envelope"></i>
				<div class="overflow-hidden">
					<h4>E-mail</h4>
					<p class="lead">
						info@patapoms.mg
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<i class="fa fa-map-marker"></i>
				<div class="overflow-hidden">
					<h4>Localisation</h4>
					<p class="lead">
						Cap 3000 Andraharo Antananarivo
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Contact info -->

<!-- Start Footer -->
<footer class="footer-area bg-f">
	<div class="container">
		<div class="row">

			<div class="col-lg-4 col-md-6">
				<h3><strong>Heures d'Ouverture</strong></h3>
				<p><span class="text-color"><strong>Lundi - Jeudi : </span>9h - 22h </strong>
				</p>
				<p><span class="text-color"><strong>Vendredi :</span> 9h - 23h</strong>
				</p>
				<p><span class="text-color"><strong>Samedi :</span> 16h - 22h</strong>
				</p>
				<p><span class="text-color"><strong>Dimanche :</span> Fermeture</strong>
				</p>
			</div>
			<div class="col-lg-4 col-md-6">
				<h3><strong>Contact information </strong></h3>
				<p class="lead">Rue Docteur Raseta, Cap3000 Andraharo Antananarivo</p>
				<p class="lead"><a href="#">+261 32 52 436 82</a></p>
				<p><a href="#"> info@patapoms.mg</a></p>
			</div>
			<div class="col-lg-3 col-md-6">
				<h3><strong>Réseaux Sociaux</strong></h3>
				<!-- <div class="subscribe_form">
					<form class="subscribe_form">
						<input name="EMAIL" id="subs-email" class="form_input" placeholder="Email Address..." type="email">
						<button type="submit" class="submit">DESCRIPTION</button>
						<div class="clearfix"></div>
					</form>
				</div -->
				<ul class="list-inline f-social">
					<li class="list-inline-item"><a href="https://www.facebook.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li class="list-inline-item"><a href="https://www.twitter.com"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<!-- <li class="list-inline-item"><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li> -->
					<li class="list-inline-item"><a href="https://www.instagram.com"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				</ul>
			</div>
		</div>
	</div>

	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<p class="company-name">All Rights Reserved. &copy; 2022 <a href="#">Pata-Poms Restaurant Bar Lounge</a>
						<a href="https://html.design/"></a>
					</p>
				</div>
			</div>
		</div>
	</div>

</footer>
<!-- End Footer -->

<a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

<!-- ALL JS FILES -->
<script src="<?php echo base_url("public/assets/");?>js/jquery-3.2.1.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/popper.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->

<script src="<?php echo base_url("public/assets/");?>js/jquery.superslides.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/images-loded.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/isotope.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/baguetteBox.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/jquery.mapify.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/form-validator.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/contact-form-script.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/custom.js"></script>
<script>
	$('.map-full').mapify({
		points: [{
			lat: 40.7143528,
			lng: -74.0059731,
			marker: true,
			title: 'Marker title',
			infoWindow: 'Yamifood Restaurant'
		}]
	});
</script>
</body>

</html>



