<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  view_reservation.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource view_reservation.php
 */;?>
<!DOCTYPE html>
<html lang="fr">
<!-- Basic -->

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Site Metas -->
	<title>Pata-Poms</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="author" content="">

	<!-- Site Icons -->
	<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">

	<?php include ("assets/stylesheets.php");?>

</head>
<style>
	.navbar{
		background: #6c757d!important;
	}
</style>
<body>
<!-- Start header -->
<?php include ("header.php");?>
<!-- End header -->
<!-- Padding Body Content -->
<div class="pd-body-content" style="padding-top: 100px;"></div>
<!-- End Padding Body Content -->
<!-- Start All Pages -->
<div class="all-page-title page-breadcrumb">
	<div class="container text-center">
		<div class="row">
			<div class="col-lg-12">
				<h1>Reservation</h1>
			</div>
		</div>
	</div>
</div>
<!-- End All Pages -->

<!-- Start Reservation -->
<div class="reservation-box">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="heading-title text-center">
					<!-- <h2>Reservation</h2> -->
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12 col-sm-12 col-xs-12">
				<div class="contact-block">
					<?php if($success):;?>
					<div class="col-md-12">
						<div class="success">
							<p><span class="label label-success">Reservation enregistrer</span>
						</div>
					</div>
					<?php endif;?>
					<form id="form-validation" method="POST" action="<?php echo base_url('reservation');?>" id="contactForm">
						<div class="row">
							<div class="col-md-6">
								<h3>Réservation de table</h3>
								<div class="col-md-12">
									<div class="form-group">
										<input id="input_date" class="datepicker picker__input form-control" placeholder="date" name="date-reservation" type="text" value="" equired data-error="Veuillez entrer la Date" required>
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<input id="input_time" class="time form-control picker__input" placeholder="heure" name="time-reservation" required data-error="Veuiller entrer l'heure">
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<select class="custom-select d-block form-control" id="person" name="person-number" required data-error="Veuillez selectionné nombre de personnes">
											<option disabled selected>Nombre de Personnes</option>
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
											<option value="4">4</option>
											<option value="5">5</option>
											<option value="6">6</option>
											<option value="7">7</option>
										</select>
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<select class="custom-select d-block from-control select" id="plats" name="order" required data-error="Veuillez entrer vos choix" multiple aria-label="multiple select example" style="width: 250px;">
											<option selected style="background:rgb(198, 215, 198) ; " value="Pata-Poms">Pata-Poms</option>
											<option value="Blancs de poulet">Blancs de poulet</option>
											<option value="Cake dinde et courgette">Cake dinde et courgette</option>
											<option value="Osso bucco dinde">Osso bucco dinde</option>
											<option value="Canard confits aux pommes sautés">Canard confits aux pommes sautés</option>
											<option value="Porc caramélisé">Porc caramélisé</option>
											<option value="Pizza Kébab">Pizza Kébab</option>
											<option value="Pizza Hawaienne">Pizza Hawaienne</option>
											<option value="Pizza La Nordique">Pizza La Nordique</option>
										</select>
										<div class="help-block with-errors"></div>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<h3>Votre Contact</h3>
								<div class="col-md-12">
									<div class="form-group">
										<input type="text" class="form-control" id="name" name="name" placeholder="Votre nom" required data-error="Votre nom">
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<input type="email" placeholder="votre mail" id="email" class="form-control" name="email" required data-error="Entrez votre mail">
										<div class="help-block with-errors"></div>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<input type="text" placeholder="votre téléphone" id="phone" class="form-control" name="phone" required data-error="Entrez votre numéro de téléphone">
										<div class="help-block with-errors"></div>
									</div>
								</div>
							</div>
							<div class="col-md-12">
								<div class="submit-button text-center">
									<!-- <button type="submit" id="submit" class="btn" onclick="myFunction()">Confirm</button> -->
									<button class="btn btn-common" id="submit" type="submit" onclick="myFunction()" style="background: rgb(224, 154, 24);">Table Réservé</button>
									<div id="msgSubmit" class="h3 text-center hidden"></div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Reservation -->

<!-- Start Contact info -->
<div class="contact-imfo-box">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<i class="fa fa-volume-control-phone"></i>
				<div class="overflow-hidden">
					<h4>Phone</h4>
					<p class="lead">
						+261 32 52 436 82
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<i class="fa fa-envelope"></i>
				<div class="overflow-hidden">
					<h4>Email</h4>
					<p class="lead">
						info@patapoms.mg
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<i class="fa fa-map-marker"></i>
				<div class="overflow-hidden">
					<h4>Localisation :</h4>
					<p class="lead">
						Cap 3000 Andraharo Antananarivo
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Contact info -->

<!-- Start Footer -->
<footer class="footer-area bg-f">
	<div class="container">
		<div class="row">

			<div class="col-lg-4 col-md-6">
				<h3><strong>Heures d'Ouverture</strong></h3>
				<p><span class="text-color"><strong>Lundi - Jeudi : </span>9h - 22h </strong>
				</p>
				<p><span class="text-color"><strong>Vendredi :</span> 9h - 23h</strong>
				</p>
				<p><span class="text-color"><strong>Samedi :</span> 16h - 22h</strong>
				</p>
				<p><span class="text-color"><strong>Dimanche :</span> Fermeture</strong>
				</p>
			</div>
			<div class="col-lg-4 col-md-6">
				<h3><strong>Contact information </strong></h3>
				<p class="lead">Rue Docteur Raseta, Cap3000 Andraharo Antananarivo</p>
				<p class="lead"><a href="#">+261 32 52 436 82</a></p>
				<p><a href="#"> info@patapoms.mg</a></p>
			</div>
			<div class="col-lg-3 col-md-6">
				<h3><strong>Réseaux Sociaux</strong></h3>
				<!-- <div class="subscribe_form">
				<form class="subscribe_form">
					<input name="EMAIL" id="subs-email" class="form_input" placeholder="Email Address..." type="email">
					<button type="submit" class="submit">DESCRIPTION</button>
					<div class="clearfix"></div>
				</form>
			</div -->
				<ul class="list-inline f-social">
					<li class="list-inline-item"><a href="https://www.facebook.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li class="list-inline-item"><a href="https://www.twitter.com"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<!-- <li class="list-inline-item"><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li> -->
					<li class="list-inline-item"><a href="https://www.instagram.com"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				</ul>
			</div>
		</div>
	</div>

	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<p class="company-name">All Rights Reserved. &copy; 2022 <a href="#">Pata-Poms Restaurant Bar Lounge</a>
						<a href="https://html.design/"></a>
					</p>
				</div>
			</div>
		</div>
	</div>


</footer>
<!-- End Footer -->

<a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

<!-- ALL JS FILES -->
<script src="<?php echo base_url("public/assets/");?>js/jquery-3.2.1.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/popper.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="<?php echo base_url("public/assets/");?>js/jquery.superslides.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/images-loded.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/isotope.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/baguetteBox.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/picker.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/picker.date.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/picker.time.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/legacy.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/form-validator.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/contact-form-script.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/custom.js"></script>
<script src="<?php echo base_url("public/assets/");?>//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
	function myFunction() {
		/*
		Swal.fire({
			title: 'Réservation Confirmée!!!',
			showClass: {
				popup: 'animate__animated animate__fadeInDown'
			},
			hideClass: {
				popup: 'animate__animated animate__fadeOutUp'
			},
			icon: "success"
		})*/
		return false;
	}
</script>
</body>

</html>



