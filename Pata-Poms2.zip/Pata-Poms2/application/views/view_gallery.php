<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  view_gallery.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource view_gallery.php
 */
;?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Site Metas -->
	<title>Pata-Poms</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="author" content="">

	<?php include "assets/stylesheets.php";?>

</head>
<style>
	.navbar{
		background: #6c757d!important;
	}
</style>
<body>
<!-- Start header -->
<?php include("header.php");?>
<!-- End header -->

<!-- Start All Pages -->
<!-- <div class="all-page-title page-breadcrumb">
	<div class="container text-center">
		<div class="row">
			<div class="col-lg-12">
			   
			</div>
		</div>
	</div>
</div> -->
<!-- End All Pages -->

<!-- Start Gallery -->
<div class="gallery-box">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<div class="heading-title text-center">

				</div>
			</div>
		</div>
		<h1 class="heading-title text-center"><strong>Nos Galeries</strong></h1>
		<div class="tz-gallery">
			<div class="row">
				<div class="col-sm-12 col-md-4 col-lg-4">
					<a class="lightbox" href="images/gallery-img-01.jpg">
						<img class="img-fluid" src="<?php echo base_url("public/assets/");?>images/gallery-img-01.jpg" alt="Gallery Images">
					</a>
				</div>
				<div class="col-sm-6 col-md-4 col-lg-4">
					<a class="lightbox" href="images/gallery-img-02.jpg">
						<img class="img-fluid" src="<?php echo base_url("public/assets/");?>images/gallery-img-02.jpg" alt="Gallery Images">
					</a>
				</div>
				<div class="col-sm-6 col-md-4 col-lg-4">
					<a class="lightbox" href="images/gallery-img-03.jpg">
						<img class="img-fluid" src="<?php echo base_url("public/assets/");?>images/gallery-img-03.jpg" alt="Gallery Images">
					</a>
				</div>
				<div class="col-sm-12 col-md-4 col-lg-4">
					<a class="lightbox" href="images/gallery-img-04.jpg">
						<img class="img-fluid" src="<?php echo base_url("public/assets/");?>images/gallery-img-04.jpg" alt="Gallery Images">
					</a>
				</div>
				<div class="col-sm-6 col-md-4 col-lg-4">
					<a class="lightbox" href="images/gallery-img-05.jpg">
						<img class="img-fluid" src="<?php echo base_url("public/assets/");?>images/gallery-img-05.jpg" alt="Gallery Images">
					</a>
				</div>
				<div class="col-sm-6 col-md-4 col-lg-4">
					<a class="lightbox" href="images/gallery-img-06.jpg">
						<img class="img-fluid" src="<?php echo base_url("public/assets/");?>images/gallery-img-06.jpg" alt="Gallery Images">
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Gallery -->

<!-- Start Customer Reviews -->
<!-- <div class="customer-reviews-box">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="heading-title text-center">
					<h2>Customer Reviews</h2>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8 mr-auto ml-auto text-center">
				<div id="reviews" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner mt-4">
						<div class="carousel-item text-center active">
							<div class="img-box p-1 border rounded-circle m-auto">
								<img class="d-block w-100 rounded-circle" src="<?php echo base_url("public/assets/");?>images/profile-1.jpg" alt="">
							</div>
							<h5 class="mt-4 mb-0"><strong class="text-warning text-uppercase">Paul Mitchel</strong></h5>
							<h6 class="text-dark m-0">Web Developer</h6>
							<p class="m-0 pt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu sem tempor, varius quam at, luctus dui. Mauris magna metus, dapibus nec turpis vel, semper malesuada ante. Idac bibendum scelerisque non non purus. Suspendisse
								varius nibh non aliquet.</p>
						</div>
						<div class="carousel-item text-center">
							<div class="img-box p-1 border rounded-circle m-auto">
								<img class="d-block w-100 rounded-circle" src="<?php echo base_url("public/assets/");?>images/profile-3.jpg" alt="">
							</div>
							<h5 class="mt-4 mb-0"><strong class="text-warning text-uppercase">Steve Fonsi</strong></h5>
							<h6 class="text-dark m-0">Web Designer</h6>
							<p class="m-0 pt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu sem tempor, varius quam at, luctus dui. Mauris magna metus, dapibus nec turpis vel, semper malesuada ante. Idac bibendum scelerisque non non purus. Suspendisse
								varius nibh non aliquet.</p>
						</div>
						<div class="carousel-item text-center">
							<div class="img-box p-1 border rounded-circle m-auto">
								<img class="d-block w-100 rounded-circle" src="<?php echo base_url("public/assets/");?>images/profile-7.jpg" alt="">
							</div>
							<h5 class="mt-4 mb-0"><strong class="text-warning text-uppercase">Daniel vebar</strong></h5>
							<h6 class="text-dark m-0">Seo Analyst</h6>
							<p class="m-0 pt-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu sem tempor, varius quam at, luctus dui. Mauris magna metus, dapibus nec turpis vel, semper malesuada ante. Idac bibendum scelerisque non non purus. Suspendisse
								varius nibh non aliquet.</p>
						</div>
					</div>
					<a class="carousel-control-prev" href="#reviews" role="button" data-slide="prev">
						<i class="fa fa-angle-left" aria-hidden="true"></i>
						<span class="sr-only">Previous</span>
					</a>
					<a class="carousel-control-next" href="#reviews" role="button" data-slide="next">
						<i class="fa fa-angle-right" aria-hidden="true"></i>
						<span class="sr-only">Next</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</div> -->
<!-- End Customer Reviews -->

<!-- Start Contact info -->
<div class="contact-imfo-box">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<i class="fa fa-volume-control-phone"></i>
				<div class="overflow-hidden">
					<h4>Téléphone</h4>
					<p class="lead">
						+261 32 52 436 82
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<i class="fa fa-envelope"></i>
				<div class="overflow-hidden">
					<h4>E-mail</h4>
					<p class="lead">
						info@patapoms.mg
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<i class="fa fa-map-marker"></i>
				<div class="overflow-hidden">
					<h4>Localisation :</h4>
					<p class="lead">
						Cap 3000 Andraharo Antananarivo
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Contact info -->

<!-- Start Footer -->
<footer class="footer-area bg-f">
	<div class="container">
		<div class="row">

			<div class="col-lg-4 col-md-6">
				<h3><strong>Heures d'Ouverture</strong></h3>
				<p><span class="text-color"><strong>Lundi - Jeudi : </span>9h - 22h </strong>
				</p>
				<p><span class="text-color"><strong>Vendredi :</span> 9h - 23h</strong>
				</p>
				<p><span class="text-color"><strong>Samedi :</span> 16h - 22h</strong>
				</p>
				<p><span class="text-color"><strong>Dimanche :</span> Fermeture</strong>
				</p>
			</div>
			<div class="col-lg-4 col-md-6">
				<h3><strong>Contact information </strong></h3>
				<p class="lead">Rue Docteur Raseta, Cap3000 Andraharo Antananarivo</p>
				<p class="lead"><a href="#">+261 32 52 436 82</a></p>
				<p><a href="#"> info@patapoms.mg</a></p>
			</div>
			<div class="col-lg-3 col-md-6">
				<h3><strong>Réseaux Sociaux</strong></h3>
				<!-- <div class="subscribe_form">
					<form class="subscribe_form">
						<input name="EMAIL" id="subs-email" class="form_input" placeholder="Email Address..." type="email">
						<button type="submit" class="submit">DESCRIPTION</button>
						<div class="clearfix"></div>
					</form>
				</div -->
				<ul class="list-inline f-social">
					<li class="list-inline-item"><a href="https://www.facebook.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li class="list-inline-item"><a href="https://www.twitter.com"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<!-- <li class="list-inline-item"><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li> -->
					<li class="list-inline-item"><a href="https://www.instagram.com"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				</ul>
			</div>
		</div>
	</div>

	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<p class="company-name">All Rights Reserved. &copy; 2022 <a href="#">Pata-Poms Restaurant Bar Lounge</a>
						<a href="https://html.design/"></a>
					</p>
				</div>
			</div>
		</div>
	</div>

</footer>
<!-- End Footer -->

<a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

<!-- ALL JS FILES -->
<script src="<?php echo base_url("public/assets/");?>js/jquery-3.2.1.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/popper.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="<?php echo base_url("public/assets/");?>js/jquery.superslides.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/images-loded.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/isotope.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/baguetteBox.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/form-validator.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/contact-form-script.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/custom.js"></script>
</body>

</html>
