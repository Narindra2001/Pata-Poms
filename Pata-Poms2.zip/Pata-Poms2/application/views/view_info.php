<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  view_info.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource view_info.php
 */;?>
<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Site Metas -->
	<title>Pata-Poms</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="author" content="">

	<?php include("assets/stylesheets.php");?>

</head>
<style>
	.navbar{
		background: #6c757d!important;
	}
</style>
<body>
<!-- Start header -->
<?php include("header.php");?>
<!-- End header -->

<!-- Start header -->
<div class="all-page-title page-breadcrumb">
	<!-- <div class="container text-center">
		<div class="row">
			<div class="col-lg-12"> -->
	<!-- <h1>A Propos de Nous</h1> -->
	<!-- </div>
</div>
</div>
</div>-->
</div>

<!-- End header -->
<h1 class="heading-title text-center"><strong>A Propos de Nous</strong></h1>
<!-- Start About -->
<div class="about-section-box">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6">
				<img src="<?php echo base_url("public/assets/");?>images/chef1.png" alt="" class="img-fluid">
				<br><br><br><br><br><br>
				<img src="<?php echo base_url("public/assets/");?>images/lounge bar.jpg" alt="" width="80%">
			</div>
			<div class="col-lg-6 col-md-6 text-center">
				<div class="inner-column">
					<h1>Bienvenue/Tongasoa/Welcome To <span> <br>Pata-Poms Restaurant & Bar Lounge</span></h1>
					<h3> <strong>Nos Petites Histoires</strong></h3>
					<p>Nous sommes un restaurant à thème et bar éco-responsable. Il s’agit d’un restaurant qui assume la responsabilité de son impact social et environnemental. Pour ce faire, le restaurant applique des mesures permettant de déduire son
						empreinte carbone et de favoriser une consommation durable. </p>
					<p>
					<h4><strong>Pata-Poms restaurant à thème</h4>100% GOURMAND et 100% BIO  </strong> <br> Un lieu unique, choix de privilégier des produits locaux. Avec des équipes passionnées par des services dans le but de satisfaire leurs clients
					et avec un Chef expérimenté. Notre restaurant est basé sur la pomme terre et de pomme. On vous propose un large choix sur nos signatures, à part nos signatures dans le menu vous trouverez aussi la gastronomie du monde et
					de la pizza. Le restaurant à une capacité de couverts 50. Ce taille est petit mais il a été choisie dans le but de garder une ambiance chaleureuse. Un restaurant à la cuisine ouverte qui n’as rien à cacher mais tout est
					en direct et partager.</p>
					<p><strong><h4>Pata-Poms bar lounge </h4></strong>Une atmosphère feutrée le soir dans notre bar lounge. Pour que les clients puissent se détendre, des canapés et des banquettes sont à votre disposition. Les musiques qui sont diffusés
					appartiennent à la catégorie de lounge music. Les boissons qu’on sert dans notre bar lounge sont variées. Il y a les cocktails qui peuvent contenir de l’alcool ou non. Vous pouvez trouvés aussi des bières en bouteilles et en
					pression, des whisky, des rhum arrangés. Pata-Poms bar lounge propose 2 Happy Hour par semaine (Jeudi – Vendredi) a partir de 17h 00 au 19h 00.</p>
					<a class="btn btn-lg btn-circle btn-outline-new-white" href="reservation.html">Reservation</a>
				</div>
			</div>
			<!-- <div class="col-md-12">
				<div class="inner-pt">
					<p>Sed tincidunt, neque at egestas imperdiet, nulla sapien blandit nunc, sit amet pulvinar orci nibh ut massa. Proin nec lectus sed nunc placerat semper. Duis hendrerit elit nec sapien porttitor, ut pretium ipsum feugiat. Aenean volutpat
						porta nisi in gravida. Curabitur pulvinar ligula sed facilisis bibendum. Nullam vitae nulla elit. </p>
					<p>Integer purus velit, eleifend eu magna volutpat, porttitor blandit lectus. Aenean risus odio, efficitur quis erat eget, mattis tristique arcu. Fusce in ante enim. Integer consectetur elit nec laoreet rutrum. Mauris porta turpis
						nec tellus accumsan pellentesque. Morbi non quam tempus, convallis urna in, cursus mauris. </p>
				</div> -->
		</div>
	</div>
</div>
</div>
<!-- End About -->



<!-- Start Contact info -->
<div class="contact-imfo-box">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<i class="fa fa-volume-control-phone"></i>
				<div class="overflow-hidden">
					<h4>Téléphone :</h4>
					<p class="lead">
						+261 32 52 436 83
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<i class="fa fa-envelope"></i>
				<div class="overflow-hidden">
					<h4>E-mail :</h4>
					<p class="lead">
						info@patapoms.mg
					</p>
				</div>
			</div>
			<div class="col-md-4">
				<i class="fa fa-map-marker"></i>
				<div class="overflow-hidden">
					<h4>Lieu :</h4>
					<p class="lead">
						Cap 3000 Andraharo Antananarivo
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Contact info -->

<!-- Start Footer -->
<footer class="footer-area bg-f">
	<div class="container">
		<div class="row">

			<div class="col-lg-4 col-md-6">
				<h3><strong>Heures d'Ouverture</strong></h3>
				<p><span class="text-color"><strong>Lundi - Jeudi : </span>9h - 22h </strong>
				</p>
				<p><span class="text-color"><strong>Vendredi :</span> 9h - 23h</strong>
				</p>
				<p><span class="text-color"><strong>Samedi :</span> 16h - 22h</strong>
				</p>
				<p><span class="text-color"><strong>Dimanche :</span> Fermeture</strong>
				</p>
			</div>
			<div class="col-lg-4 col-md-6">
				<h3><strong>Contact information </strong></h3>
				<p class="lead">Rue Docteur Raseta, Cap3000 Andraharo Antananarivo</p>
				<p class="lead"><a href="#">+261 32 52 436 82</a></p>
				<p><a href="#"> info@patapoms.mg</a></p>
			</div>
			<div class="col-lg-3 col-md-6">
				<h3><strong>Réseaux Sociaux</strong></h3>
				<!-- <div class="subscribe_form">
					<form class="subscribe_form">
						<input name="EMAIL" id="subs-email" class="form_input" placeholder="Email Address..." type="email">
						<button type="submit" class="submit">DESCRIPTION</button>
						<div class="clearfix"></div>
					</form>
				</div -->
				<ul class="list-inline f-social">
					<li class="list-inline-item"><a href="https://www.facebook.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li class="list-inline-item"><a href="https://www.twitter.com"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<!-- <li class="list-inline-item"><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li> -->
					<li class="list-inline-item"><a href="https://www.instagram.com"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
				</ul>
			</div>
		</div>
	</div>


	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<p class="company-name">All Rights Reserved. &copy; 2022 <a href="#">Pata-Poms Restaurant Bar Lounge</a>
						<a href="https://html.design/"></a>
					</p>
				</div>
			</div>
		</div>
	</div>

</footer>
<!-- End Footer -->

<a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

<?php include ("assets/script.php");?>
</body>

</html>


