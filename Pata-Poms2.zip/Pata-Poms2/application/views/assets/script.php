<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  script.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource script.php
 */;?>
<!-- ALL JS FILES -->
<script src="<?php echo base_url("public/assets/");?>js/jquery-3.2.1.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/popper.min.js"></script>
<script src="<?php echo base_url("public/assets/")?>js/bootstrap.min.js"></script>
<!-- ALL PLUGINS -->
<script src="<?php echo base_url("public/assets/");?>js/jquery.superslides.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/images-loded.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/isotope.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/baguetteBox.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/form-validator.min.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/contact-form-script.js"></script>
<script src="<?php echo base_url("public/assets/");?>js/custom.js"></script>


