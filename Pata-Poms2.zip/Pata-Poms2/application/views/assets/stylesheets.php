<?php
/*
 *  ------------------------------------------------------------------------------------
 *  Pata-Poms (c) 2022
 *  ------------------------------------------------------------------------------------
 *  Copyright (c) 2022 Pata-Poms.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of Pata-Poms.
 *  You shall not disclose such Confidential Information and shall use it only in
 *  accordance width the terms of the license agreement you entered into width
 *  Pata-Poms.
 *  ------------------------------------------------------------------------------------
 *  stylesheets.php
 *  ------------------------------------------------------------------------------------
 *
 *  @category Pata-Poms
 *  @copyright Copyright (c) 2022
 *  @since Version 2022.0.0
 *  @filesource stylesheets.php
 */
;?>

<!-- Site Icons -->
<link rel="shortcut icon" href="<?php echo base_url("public/assets/");?>images/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="<?php echo base_url("public/assets/");?>images/apple-touch-icon.png">

<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?php echo base_url("public/assets/");?>css/bootstrap.min.css">
<!-- Site CSS -->
<link rel="stylesheet" href="<?php echo base_url("public/assets/");?>css/style.css">
<!-- Pickadate CSS -->
<link rel="stylesheet" href="<?php echo base_url("public/assets/");?>css/classic.css">
<link rel="stylesheet" href="<?php echo base_url("public/assets/");?>css/classic.date.css">
<link rel="stylesheet" href="<?php echo base_url("public/assets/");?>css/classic.time.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="<?php echo base_url("public/assets/");?>css/responsive.css">
<!-- Custom CSS -->
<link rel="stylesheet" href="<?php echo base_url("public/assets/");?>css/custom.css">


