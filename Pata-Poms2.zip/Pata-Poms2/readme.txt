/*****************************************
Installations 
*****************************************/
1 - Installer pata-poms.sql dans la base de donnee
2 - Configurer la base du framework dans application/config/database.php et config.php base_url
3 - activer le serveu
4 - Aller dans l'addresse localhost/